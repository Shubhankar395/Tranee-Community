import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import doe from '../../img/doe.jpg';

export class Profiles extends Component {
    render() {
        return (
            <div>
                <div className=" card shadow p-3 mb-5 bg-body rounded container mt-5" style={{ width: "26rem", height: "16rem", }}>
                    <div>
                        <h1 className=" fs-1">
                            <img src={doe}
                                style={{ height: "70px", width: "70px", float: "left" }}
                                className="rounded-circle" />
                            John Doe
                        </h1>
                        <h5 style={{ marginLeft: "25%" }}>Devloper at Microsoft</h5> <br />
                        <h5 style={{ marginRight: "5%" }}>Sattel,WA</h5>
                    </div>
                    <div className="card-body" style={{ marginRight: "1%" }}>
                        <Link to="/profile" className="btn btn-info text-light fs-5 "> View Profile</Link>
                    </div>
                </div>
            </div>
        )
    }
}

export default Profiles;