import React from 'react'

export default function Post() {
  return (
    <div>
            <nav className="navbar navbar-expand-sm navbar-dark bg-dark mb-4">
        <div className="container">
            <a className="navbar-brand" href="landing.html">TraineeCommunity</a>
            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#mobile-nav">
                <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="mobile-nav">
                <ul className="navbar-nav mr-auto">
                    <li className="nav-item">
                        <a className="nav-link" href="profiles.html">Developer</a>
                    </li>
                </ul>
                <ul className="navbar-nav ml-auto">
                    <li className="nav-item">
                        <a className="nav-link" href="feed.html">Post Feed</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="dashboard.html">Dashboard</a>
                    </li>
                    <li className="nav-item">
                        <a href="#" className="nav-link">
                            <img className="rounded-circle" style="width: 25px;margin-right: 5px;" src="https://www.gravatar.com/avatar/anything?s=200&d=mm" alt="" title="You Must Have A Gravatar Connected To Your Email To Display An Image"/>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    {/* <!-- Post --> */}
    <div className="post">
        <div className="container">
            <div className="row">
                <div className="col-md-12">
                    {/* <!--Post Item--> */}
                    <div className="card card-body mb-3">
                        <div className="row">
                            <div className="col-md-2">
                                <a href="profile.html">
                                    <img className="rounded-circle d-none d-md-block" src="../img/doe.jpg" style="height: 180px; width:180px;" alt=""/>
                                </a>
                                <br/>
                                <p className="text-center">John Doe</p>
                            </div>
                            <div className="col-md-10 p-md-5">
                                <p className="lead">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Eveniet voluptates, debitis enim sequi cupiditate tempore asperiores at maiores magni hic explicabo dolor animi laudantium natus porro unde! Quidem, optio nostrum.</p>
                            </div>
                        </div>
                    </div>
                    {/* <!--Comment Form--> */}
                    <div className="post-form mb-3">
                        <div className="card card-info">
                            <div className="card-header bg-info text-white">
                                Say Something...
                            </div>
                            <div className="card-body">
                                <form>
                                    <div className="form-group">
                                        <textarea className="form-control from-control-lg" placeholder="Create a post"></textarea>
                                    </div>
                                    <button type="submit" className="btn btn-dark">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    {/* <!--Comment Feed--> */}
                    <div className="comments">
                        {/* <!--Comment item--> */}
                        <div className="card card-body mb-3">
                            <div className="row">
                                <div className="col-md-2">
                                    <a href="profile.html">
                                        <img className="rounded-circle d-none d-md-block" src="https://www.gravatar.com/avatar/anything?s=200&d=mm" alt=""/>
                                    </a>
                                    <br/>
                                    <p className="text-center">Kevin Smith</p>
                                </div>
                                <div className="col-md-10 p-md-5">
                                    <p className="lead">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Eveniet voluptates, debitis enim sequi cupiditate tempore asperiores at maiores magni hic explicabo dolor animi laudantium natus porro unde! Quidem, optio nostrum.</p>
                                </div>
                            </div>
                        </div>
                        <div className="card card-body mb-3">
                            <div className="row">
                                <div className="col-md-2">
                                    <a href="profile.html">
                                        <img className="rounded-circle d-none d-md-block" src="https://www.gravatar.com/avatar/anything?s=200&d=mm" alt=""/>
                                    </a>
                                    <br/>
                                    <p className="text-center">Karen Johnson</p>
                                </div>
                                <div className="col-md-10 p-md-5">
                                    <p className="lead">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Eveniet voluptates, debitis enim sequi cupiditate tempore asperiores at maiores magni hic explicabo dolor animi laudantium natus porro unde! Quidem, optio nostrum.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer className="bg-dark text-white mt-5 p-4 text-center">Copyright &copy; 2018
        Trainee Connector</footer>

    </div>
  )
}
