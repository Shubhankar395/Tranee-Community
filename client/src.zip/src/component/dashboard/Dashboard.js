import React from 'react';

export default function Dashboard() {
    return (
        <div>
            <nav className="navbar navbar-expand-sm navbar-dark bg-dark mb-4">
                <div className="container">
                    <a className="navbar-brand" href="../landing/landing.html">TraineeCommunity</a>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#mobile-nav">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="mobile-nav">
                        <ul className="navbar-nav mr-auto">
                            <li className="nav-item">
                                <a className="nav-link" href="../profiles/profiles.html">Trainees</a>
                            </li>
                        </ul>
                        <ul className="navbar-nav ml-auto">
                            <li className="nav-item">
                                <a className="nav-link" href="../feeds/feed.html">Post Feed</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="../dashboard/dashboard.html">Dashboard</a>
                            </li>
                            <li className="nav-item">
                                <a href="#" className="nav-link">
                                    <img className="rounded-circle" style="width: 25px;margin-right: 5px;" src="https://www.gravatar.com/avatar/anything?s=200&d=mm" alt="" title="You Must Have A Gravatar Connected To Your Email To Display An Image" />
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            {/* <!-- dashbord --> */}
            <div className="dashboard">
                <div className="container">

                    <div className="row">

                        <div className="col-md-12">

                            <h1 className="display-4">Dashboard</h1>
                            <p className="lead text-muted">Welcome John Doe</p>

                            {/* <!-- Dashboard Actions --> */}
                            <div className="btn-group mb-4" role="group">
                                <a href="../edit-profile/edit-profile.html" className="btn btn-light">
                                    <i className="fa fa-user-circle text-info mr-1"></i> Edit Profile</a>
                                <a href="../add-experiences/add-experience.html" className="btn btn-light">
                                    <i className="fab fa-black-tie text-info mr-1"></i>Add Experience</a>
                                <a href="../add-education/add-education.html" className="btn btn-light">
                                    <i className="fas fa-graduation-cap text-info mr-1"></i> Add Education</a>
                            </div>

                            {/* <!-- Experience --> */}

                            <div>
                                <h4 className="mb-2">Experience Credentials</h4>
                                <table className="table">
                                    <thead>
                                        <tr>
                                            <th>Company</th>
                                            <th>Title</th>
                                            <th>Years</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Tech Guy Web Solutions</td>
                                            <td>Senior Trainee</td>
                                            <td>02-03-2009-01-02-2014</td>
                                            <td><button className="btn btn-danger">Delete</button></td>
                                        </tr>
                                        <tr>
                                            <td>Micron Infotech</td>
                                            <td>Instructor and Trainee</td>
                                            <td>02-03-2015-Now</td>
                                            <td><button className="btn btn-danger">Delete</button></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            {/* <!-- Education --> */}
                            <div>
                                <h4 className="mb-2">EducationCredentials</h4>
                                <table className="table">
                                    <thead>
                                        <tr>
                                            <th>School</th>
                                            <th>Degree</th>
                                            <th>Years</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Tech Guy Web Solutions</td>
                                            <td>Senior Trainee</td>
                                            <td>02-03-2009-01-02-2014</td>
                                            <td><button className="btn btn-danger">Delete</button></td>
                                        </tr>
                                        <tr>
                                            <td>Micron Infotech</td>
                                            <td>Instructor and Trainee</td>
                                            <td>02-03-2015-Now</td>
                                            <td><button className="btn btn-danger">Delete</button></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <button className="btn btn-danger">Delete My Account</button>
                            </div>
                        </div>
                    </div>
                </div>
                <footer className="bg-dark text-white mt-5 p-4 text-center">Copyright &copy; 2022
                    TraineeCommunity</footer>
            </div>
        </div>
    );
}
