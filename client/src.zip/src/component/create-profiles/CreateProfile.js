import React from 'react'

export default function CreateProfile() {
    return (
        <div>
            <nav className="navbar navbar-expand-sm navbar-dark bg-dark mb-4">
                <div className="container">
                    <a className="navbar-brand" href="../landing/landing.html">TraineeCommunity</a>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#mobile-nav">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="mobile-nav">
                        <ul className="navbar-nav mr-auto">
                            <li className="nav-item">
                                <a className="nav-link" href="../profiles/profiles.html">Developer</a>
                            </li>
                        </ul>
                        <ul className="navbar-nav ml-auto">
                            <li className="nav-item">
                                <a className="nav-link" href="../feeds/feed.html">Post Feed</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="../dashboard/dashboard.html">Dashboard</a>
                            </li>
                            <li className="nav-item">
                                <a href="#" className="nav-link">
                                    <img className="rounded-circle" style="width: 25px;margin-right: 5px;" src="https://www.gravatar.com/avatar/anything?s=200&d=mm" alt="" title="You Must Have A Gravatar Connected To Your Email To Display An Image" />
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            {/* <!-- Add Education --> */}
            <div className="create-profile">
                <div className="container">
                    <div className="row">
                        <div className="col-md-8 m-auto">
                            <a href="../dashboard/dashboard.html" className="btn btn-info">
                                Go Back
                            </a>
                            <h1 className="display-4 text-center">Create Your Profile</h1>
                            <p className="lead text-center">Let's get some information to make your profile stand out</p>
                            <small className="d-block pb-3">* = required field</small>
                            <form action="../add-education/add-education.html">
                                <div className="form-group">
                                    <input type="text" className="form-control form-control-lg" placeholder="* Profile Handle" name="handle" required />
                                    <small className="form-text text-muted">A unique handle for your profile URL. Your full name, company name, nickname, etc(This CAN'T be changed later)</small>
                                </div>
                                <div className="form-group">
                                    <select className="form-control form-control-lg" name="status">
                                        <option value="0">Select Professional Status</option>
                                        <option value="Developer">Developer</option>
                                        <option value="Junior Developer">Junior Developer</option>
                                        <option value="Senior Developer">Senior Developer</option>
                                        <option value="Manager">Manager</option>
                                        <option value="Student or Learning">Student or Learning</option>
                                        <option value="Instructor">Instructor or Teacher</option>
                                        <option value="Intern">Intern</option>
                                        <option value="Other">Other</option>
                                    </select>
                                    <small className="form-text text-muted">Give us an idea of where you are at in your career</small>
                                </div>
                                <div className="form-group">
                                    <input type="text" className="form-control form-control-lg" placeholder="Company" name="company" />
                                    <small className="form-text text-muted">Could be your own company or one you work for</small>
                                </div>
                                <div className="form-group">
                                    <input type="date" className="form-control form-control-lg" placeholder="Website" name="website" />
                                    <small className="form-text text-muted">Could be your own or a company website</small>
                                </div>
                                <div className="form-group">
                                    <input type="Date" className="form-control form-control-lg" placeholder="Location" name="location" />
                                    <small className="form-text text-muted">City & state suggested(eg. Boston, MA)</small>
                                </div>
                                <div className="form-check mb-4">
                                    <input type="checkbox" className="form-check-input" placeholder="Skills" name="skills" />
                                    <small className="form-text text-muted">Please use comma separated values (eg. HTML, CSS, Javascript,PHP)</small>
                                </div>
                                <div className="form-check mb-4">
                                    <input type="checkbox" className="form-check-input" placeholder="Github Username" name="githubusername" />
                                    <small className="form-text text-muted">If you want your latest repos and a Github link, include your username</small>
                                </div>
                                <div className="form-group">
                                    <textarea className="form-control form-control-lg" placeholder="A short bio of yourself" name="bio"></textarea>
                                    <small className="form-text text-muted">Tell us a little about yourself</small>
                                </div>
                                <div className="mb-3">
                                    <button type="button" className="btn btn-light">Add Social Network Links</button>
                                    <span className="text-muted">Optional</span>
                                </div>
                                <div className="input-group mb-3">
                                    <div className="input-group-prepend">
                                        <span className="input-group-text">
                                            <i className="fab fa-twitter"></i>
                                        </span>
                                    </div>
                                    <input type="text" className="form-control form-control-lg" placeholder="Twitter Profile URL" name="twitter" />
                                </div>
                                <div className="input-group mb-3">
                                    <div className="input-group-prepend">
                                        <span className="input-group-text">
                                            <i className="fab fa-facebook"></i>
                                        </span>
                                    </div>
                                    <input type="text" className="form-control form-control-lg" placeholder="Facebook Page URL" name="facebook" />
                                </div>
                                <div className="input-group mb-3">
                                    <div className="input-group-prepend">
                                        <span className="input-group-text">
                                            <i className="fab fa-linkedin"></i>
                                        </span>
                                    </div>
                                    <input type="text" className="form-control form-control-lg" placeholder="Linkedin Profile URL" name="linkedin" />
                                </div>
                                <div className="input-group mb-3">
                                    <div className="input-group-prepend">
                                        <span className="input-group-text">
                                            <i className="fab fa-youtube"></i>
                                        </span>
                                    </div>
                                    <input type="text" className="form-control form-control-lg" placeholder="Youtube Channel URL" name="youtube" />
                                </div>
                                <div className="input-group mb-3">
                                    <div className="input-group-prepend">
                                        <span className="input-group-text">
                                            <i className="fab fa-instagram"></i>
                                        </span>
                                    </div>
                                    <input type="text" className="form-control form-control-lg" placeholder="Instagram Page URL" name="instagram" />
                                </div>
                                <input type="submit" className="btn btn-info btn-block mt-4" />
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <footer className="bg-dark text-white mt-5 p-4 text-center">Copyright &copy; 2018
                Trainee Connector</footer>
        </div>
    )
}
