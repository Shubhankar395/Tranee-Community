import React from 'react'

export default function AddEducation() {
    return (
        <div>

            <div className="section add-education">
                <div className="container">
                    <div className="row">
                        <div className="col-md-8 m-auto">
                            <a href="dashboard.html" className="btn btn-light">
                                Go Back
                            </a>
                            <h1 className="display-4 text-center">Add Your Education</h1>
                            <p className="lead text-center">Add any school/collage, bootcamp, etc that you have attend</p>
                            <small className="d-block pb-3">* = required field</small>
                            <form action="/education">
                                <div className="form-group">
                                    <input type="text" className="form-control form-control-lg" placeholder="* School Or Bootcamp" name="school" required />
                                </div>
                                <div className="form-group">
                                    <input type="text" className="form-control form-control-lg" placeholder="* Degree Or Certificate Name" name="degree" required />
                                </div>
                                <div className="form-group">
                                    <input type="text" className="form-control form-control-lg" placeholder="* Field Of Study" name="fieldofstudy" />
                                </div>
                                <h6>From Date</h6>
                                <div className="form-group">
                                    <input type="date" className="form-control form-control-lg" name="from" />
                                </div>
                                <h6>To Date</h6>
                                <div className="form-group">
                                    <input type="Date" className="form-control form-control-lg" name="to" />
                                </div>
                                <div className="form-check mb-4">
                                    <input type="checkbox" className="form-check-input" name="current" value="" id="current" />
                                    <label for="current" className="form-check-label">
                                        Current Job
                                    </label>
                                </div>
                                <div className="form-group">
                                    <textarea className="form-control form-control-lg" placeholder="Programme Description" name="description"></textarea>
                                    <small className="form-text text-muted">Tell us about your experience and what you learned</small>
                                </div>
                                <input type="submit" className="btn btn-info btn-block mt-4" />
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
