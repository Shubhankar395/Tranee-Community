import React,{Component} from 'react'
import { Link } from 'react-router-dom'
import doe from '../../img/doe.jpg';

export class Profile extends Component{
  render() {
    return (
      <div>
          <div className="profile">
                <div className="container">
                    <div className="row">
                        <div className="col-md-12">
                            <div className="row">
                                <div className="col-6">
                                    <Link to="/profiles" className="btn btn-light mb-3 float-left">Back To Profiles</Link>
                                </div>
                                <div className="col-6">

                                </div>
                            </div>

                            {/* <!-- Profile Header --> */}
                            <div className="row">

                                <div className="col-md-12">
                                    <div className="card card-body bg-info text-white mb-3">
                                        <div className="row">
                                            <div className="col-4 col-md-3 m-auto">
                                                <img className="rounded-circle navbar-expand-sm"
                                                    src={doe}
                                                    alt=""
                                                    style={{height: "150px", width: "150px", left: "50px", position: "relative"}} />
                                            </div>
                                        </div>
                                        <div className="text-center">
                                            <h1 className="display-4 text-center">John Doe</h1>
                                            <p className="lead text-center">Trainee at Microsoft</p>
                                            <p>Seattle, WA</p>
                                            <p>
                                                <Link className="text-white p-2" to="#">
                                                    <i className="fas fa-globe fa-2x"></i>
                                                </Link>
                                                <Link className="text-white p-2" to="#">
                                                    <i className="fab fa-twitter fa-2x"></i>
                                                </Link>
                                                <Link className="text-white p-2" to="#">
                                                    <i className="fab fa-facebook fa-2x"></i>
                                                </Link>
                                                <Link className="text-white p-2" to="#">
                                                    <i className="fab fa-linkedin fa-2x"></i>
                                                </Link>
                                                <Link className="text-white p-2" to="#">
                                                    <i className="fab fa-instagram fa-2x"></i>
                                                </Link>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* <!--Profile About--> */}
                            <div className="row">
                                <div className="col-md-12">
                                    <div className="card card-body bg-light mb-3">
                                        <h3 className="text-center text-info">John's Bio</h3>
                                        <p className="lead">Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere
                                            aspernatur reiciendis soluta, aperiam, architecto, eius dolor dignissimos harum
                                            deserunt nesciunt molestias beatae delectus magnam. Laborum accusamus voluptates
                                            veritatis beatae quod!</p>
                                        <hr />
                                        <h3 className="text-center text-info">Skill Set</h3>
                                        <div className="row">
                                            <div className="d-flex flex-wrap justify-content-center align-items-center">
                                                <div className="p-3">
                                                    <i className="fa fa-check"></i>
                                                    JavaScript
                                                </div>
                                                <div className="p-3">
                                                    <i className="fa fa-check"></i>
                                                    Java
                                                </div>
                                                <div className="p-3">
                                                    <i className="fa fa-check"></i>
                                                    C#
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* <!--Profile Creds--> */}
                                <div className="row">
                                    <div className="col-md-6">
                                        <h3 className="text-center text-info">Experience</h3>
                                        <ul className="list-group">
                                            <li className="list-group-item">
                                                <h4>Microsoft</h4>
                                                <p>Oct 2011 - Current</p>
                                                <p>
                                                    <strong>Position : </strong>Senior Trainee
                                                </p>
                                                <p>
                                                    <strong>Description</strong>Lorem ipsum dolor sit amet consectetur
                                                    adipisicing elit. Nisi quidem doloribus aliquam expedita repudiandae dolore,
                                                    laudantium maxime quam quis illum autem dolores eius quod ullam unde vitae
                                                    veritatis. Natus, fuga.
                                                </p>
                                            </li>
                                            <li className="list-group-item">
                                                <h4>Sun Microsystems</h4>
                                                <p>Oct 2004 - Nov 2011</p>
                                                <p>
                                                    <strong>Position : </strong>Systems Admin
                                                </p>
                                                <p>
                                                    <strong>Location : </strong>Miami, FL
                                                </p>
                                                <p>
                                                    <strong>Description</strong>Lorem ipsum dolor sit amet consectetur
                                                    adipisicing elit. Nisi quidem doloribus aliquam expedita repudiandae dolore,
                                                    laudantium maxime quam quis illum autem dolores eius quod ullam unde vitae
                                                    veritatis. Natus, fuga.
                                                </p>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="col-md-6">
                                        <h3 className="text-center text-info">Education</h3>
                                        <ul className="list-group">
                                            <li className="list-group-item">
                                                <h4>University Of Washington</h4>
                                                <p>Sep 1993 - June 1999</p>
                                                <p>
                                                    <strong>Degree : </strong>Master
                                                </p>
                                                <p>
                                                    <strong>Field Of Study : </strong>Computer Science
                                                </p>
                                                <p>
                                                    <strong>Description</strong>Lorem ipsum dolor sit amet consectetur
                                                    adipisicing elit. Nisi quidem doloribus aliquam expedita repudiandae dolore,
                                                    laudantium maxime quam quis illum autem dolores eius quod ullam unde vitae
                                                    veritatis. Natus, fuga.
                                                </p>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                {/* <!--Profile Github--> */}
                                <div ref="myRef">
                                    <hr />
                                    <h3 className="mb-4">Latest Github Repos</h3>
                                    <div className="card card-body mb-2">
                                        <div className="row">
                                            <div className="col-md-6">
                                                <h4>
                                                    <Link className="text-info" target="_blank">Repository One</Link>
                                                </h4>
                                                <p>Repository Description</p>
                                            </div>
                                            <div className="col-md-6">
                                                <span className="badge badge-info mr-1">
                                                    Stars : 44
                                                </span>
                                                <span className="badge badge-secondry mr-1">
                                                    Watchers : 21
                                                </span>
                                                <span className="badge badge-success">
                                                    Forks : 122
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
      </div>
    )
  }
}

export default Profile