import React from 'react'

export default function AddExperience() {
    return (
        <div>
            <nav className="navbar navbar-expand-sm navbar-dark bg-dark mb-4">
                <div className="container">
                    <a className="navbar-brand" href="../landing/landing.html">TraineeCommunity</a>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#mobile-nav">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="mobile-nav">
                        <ul className="navbar-nav mr-auto">
                            <li className="nav-item">
                                <a className="nav-link" href="../profiles/profiles.html">Developer</a>
                            </li>
                        </ul>
                        <ul className="navbar-nav ml-auto">
                            <li className="nav-item">
                                <a className="nav-link" href="../feeds/feed.html">Post Feed</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="../dashboard/dashboard.html">Dashboard</a>
                            </li>
                            <li className="nav-item">
                                <a href="#" className="nav-link">
                                    <img className="rounded-circle" style="width: 25px;margin-right: 5px;" src="https://www.gravatar.com/avatar/anything?s=200&d=mm" alt="" title="You Must Have A Gravatar Connected To Your Email To Display An Image" />
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            {/* <!-- Add Experience --> */}
            <div className="section add-experience">
                <div className="container">
                    <div className="row">
                        <div className="col-md-8 m-auto">
                            <a href="../dashboard/dashboard.html" className="btn btn-light">
                                Go Back
                            </a>
                            <h1 className="display-4 text-center">Add Your Experience</h1>
                            <p className="lead text-center">Add any developer/programming positions that you have had in the past</p>
                            <small className="d-block pb-3">* = required field</small>
                            <form action="add-education.html">
                                <div className="form-group">
                                    <input type="text" className="form-control form-control-lg" placeholder="* Job Title" name="title" required />
                                </div>
                                <div className="form-group">
                                    <input type="text" className="form-control form-control-lg" placeholder="* Company" name="company" required />
                                </div>
                                <div className="form-group">
                                    <input type="text" className="form-control form-control-lg" placeholder="* Location" name="location" />
                                </div>
                                <h6>From Date</h6>
                                <div className="form-group">
                                    <input type="date" className="form-control form-control-lg" name="from" />
                                </div>
                                <h6>To Date</h6>
                                <div className="form-group">
                                    <input type="Date" className="form-control form-control-lg" name="to" />
                                </div>
                                <div className="form-check mb-4">
                                    <input type="checkbox" className="form-check-input" name="current" value="" id="current" />
                                    <label for="current" className="form-check-label">
                                        Current Job
                                    </label>
                                </div>
                                <div className="form-group">
                                    <textarea className="form-control form-control-lg" placeholder="Job Description" name="description"></textarea>
                                    <small className="form-text text-muted">Some of your responsabilities, etc</small>
                                </div>
                                <input type="submit" className="btn btn-info btn-block mt-4" />
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <footer className="bg-dark text-white mt-5 p-4 text-center">Copyright &copy; 2018
                Trainee Connector</footer>
        </div>
    )
}
